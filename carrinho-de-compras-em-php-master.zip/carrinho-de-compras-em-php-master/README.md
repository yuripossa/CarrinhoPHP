# carrinho-de-compras-em-php
Este repositório tem como objetivo o desenvolvimento de um sistema de carrinhos de compras feito em php. <br />

<h5>Como utilizar o sistema</h5>
1 - Configure suas credenciais de BD no arquivo conexao presente na pasta DataBase <br />
2 - Basta executar o codigo sql do arquivo db.sql presente na pasta DataBase <br />
3 - Coloque o projeto em um localhost.


